# JS-enabled demo Mongoose OS firmware

This is the JS demo Mongoose OS app. It gets installed by default at
[Mongoose OS installation step](https://mongoose-os.com/docs/). It has
a lot of functionality enabled - cloud integrations, JavaScript engine, etc.
Its main purpose is to demonstrate the capabilities of Mongoose OS.
